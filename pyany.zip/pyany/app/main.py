import re
from flask import Flask,jsonify,request,session,render_template
from sqlalchemy import Table, create_engine, MetaData, func
from sqlalchemy.orm import Session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.sql import and_,asc,desc,or_
from sqlalchemy.ext.declarative import declarative_base
import pymysql
import datetime

from sqlalchemy import DateTime


pymysql.install_as_MySQLdb()

app = Flask(__name__)
#app.secret_key = "hello"

# app.config['SQLALCHEMY_DATABASE_URI'] = "mysql://admin:12345678@database-5.cnrg8y5sizwf.us-east-1.rds.amazonaws.com:3306/Library"
app.config['SECRET_KEY']='12345678' 
app.config['SQLALCHEMY_DATABASE_URI'] = "mysql://admin:12345678@database-5.cnrg8y5sizwf.us-east-1.rds.amazonaws.com:3306/Library"
# app.permanent_session_lifetime = timedelta(minutes=5)

app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = True

db = SQLAlchemy(app)

engine = create_engine('mysql://admin:12345678@database-5.cnrg8y5sizwf.us-east-1.rds.amazonaws.com:3306/Library')
metadata = MetaData(bind=engine)
session = Session(engine)

# id = db.Column(db.Integer,primary_key = "True")
# userName = db.Column(db.String(200),nullable = False)
# userPassword = db.Column(db.String(200),nullable = False)

class Publisher(db.Model):
    name = db.Column(db.String(50),primary_key=True)
    address = db.Column(db.String(50))
    phone = db.Column(db.String(10))


class Author(db.Model):

    authorid = db.Column(db.Integer,primary_key = True)
    authorname = db.Column(db.String(50))

class Book(db.Model):
    bookid = db.Column(db.Integer,primary_key = True)
    title = db.Column(db.String(50))
    publishername = db.Column(db.ForeignKey('publisher.name'))
    author = db.Column(db.ForeignKey('author.authorid'))

# class Library_Branch(db.Model):
#    branchid = db.Column(db.Integer,primary_key = True)
#    branchname = db.Column(db.String(50))
#    address = db.Column(db.String(50))

class Borrower(db.Model):
    cardno = db.Column(db.Integer,primary_key = True)
    name = db.Column(db.String(50))
    address = db.Column(db.String(50))
    phone = db.Column(db.String(10))


Book_Copies = Table('book_copies', metadata, autoload=True, autoload_with=engine)
Library_Branch = Table('library_branch', metadata, autoload=True, autoload_with=engine)
Book_Loans = Table('book_loans', metadata, autoload=True, autoload_with=engine)

def queryBookby_bookId(bookId):
   return session.query(Book).filter(Book.bookid == bookId).first()
"""
end point : publicSearch
"""
@app.route('/publichSearch', methods=['POST', 'GET'])
def publichSearch():
   
   lstResult = []
   # get user input
   input = request.form['authorNameOrTitle']
   print('INPUT IS',input)
   #input = 'Harry Potter'
   # if input is authorName or input is a book title
   queryBookby_authorNameOrTitle = session.query(Book).join(Author).filter(or_(Author.authorname == input,Book.title == input))
   session.rollback
   if queryBookby_authorNameOrTitle.all():
      book = queryBookby_authorNameOrTitle.first()
      bookid = book.bookid
      bookName = book.title
      AuthorId = book.author
      author = session.query(Author).filter(Author.authorid == AuthorId).first()

      authorName = author.authorname
      publishName = book.publishername
   else:
      return jsonify({'message':['error','there is no match book title or author found']})
      
   queryBook_Copiesby_bookId = session.query(Book_Copies).filter(Book_Copies.c.BookId == bookid)
   session.rollback
   if queryBook_Copiesby_bookId.all():
      book_copies = queryBook_Copiesby_bookId.all()
      for i in book_copies:
         branchid = i[1]
         queryBranchby_branchId = session.query(Library_Branch).filter(Library_Branch.c.BranchId == branchid)
         branch = queryBranchby_branchId.first()
         branchName = branch.BranchName
         leftNumber = i[2]
         lstResult.append({"branchName":branchName,"bookName":bookName,"publisher":publishName,'leftNumber':leftNumber,'authorName':authorName})

   return jsonify({'message':['success',lstResult]})
   
  



@app.route('/loadLibraries', methods=['POST', 'GET'])
def loadLibraries():
    lstResult = []
    queryAllLibrary = session.query(Library_Branch)
    session.rollback
    if queryAllLibrary.all():
       libraries = queryAllLibrary.all()
       for library in libraries:
          lstResult.append({'library_branchName':library.BranchName})
    else:
       return jsonify({'message':['error','there is no library branch found']})
    return jsonify(lstResult)

@app.route('/loadBookofLibrary', methods=['POST', 'GET'])
def loadBookofLibrary():
    lstResult = []
    input = request.form['branchName']
    #input = 'Montreal_branch'
    # first make sure the branchId

    queryBranchby_BranchName = session.query(Library_Branch).filter(Library_Branch.c.BranchName == input)
    session.rollback
    if queryBranchby_BranchName.all():
        branch = queryBranchby_BranchName.first()
        branchId = branch.BranchId

    #find many books and book info through branchId

    queryBook_Copisby_BranchId = session.query(Book_Copies).filter(Book_Copies.c.BranchId == branchId)
    session.rollback

    if queryBook_Copisby_BranchId.all():
        book_copies = queryBook_Copisby_BranchId.all()
        for i in book_copies:
            bookId = i[0]
            book = queryBookby_bookId(bookId)
            lstResult.append({'bookName':book.title,'publisher':book.publishername,'bookleft':i.No_Of_Copies})
    else:
       return jsonify({'message': ['error', 'there is no book_copies found']})
    return jsonify(lstResult)

def queryBorrowerby_cardnoOrName(input):
    return session.query(Borrower).\
        filter(or_(Borrower.cardno == input,Borrower.name == input))

def queryby_cardno(input):
    return session.query(Library_Branch,Book,Borrower,Book_Loans).\
        join(Book_Loans,Book_Loans.c.BookId == Book.bookid).\
        join(Borrower,Book_Loans.c.CardNo == Borrower.cardno).\
        join(Library_Branch,Library_Branch.c.BranchId == Book_Loans.c.BranchId).\
        filter(Borrower.cardno == input)
@app.route('/loadBorrowerRecord', methods=['POST', 'GET'])
def loadBorrowerRecord():
    lstResult = []
    #input cardno
    input = request.form['cardNo']
    #get all info
    find = queryby_cardno(input).all()
    if find:
        for i in find:
            book = i[3]
            borrower = i[4]

            lstResult.append({'bookName':book.title,
                              'branchName':i[1],
                              'borrowerName':borrower.name,
                              'dateOut':i[8],
                              'dueDate':i[9],
                              'returnState':i[10]})
    else:
        return jsonify({'message':['error','there is no cardno or borrower name found']})
    return jsonify({'message':['success',lstResult]})

def queryBookby_title(input):
    return session.query(Book).filter(Book.title == input).first()
def queryBorrowerby_cardno(input):
    return session.query(Borrower).filter(Borrower.cardno == input).first()
def queryBranchby_branchid(input):
    return session.query(Library_Branch).filter(Library_Branch.c.BranchId == input).first()
def queryBook_Copiesby_branchidAndbookid(input1,input2):
    #input1 is branchId,input2 is BookId
    return session.query(Book_Copies).filter(Book_Copies.c.BranchId == input1,Book_Copies.c.BookId == input2)
def addLoansRecord(bookId,input2,input1):
    ins = Book_Loans.insert()
    currentTime = datetime.datetime.now()
    dueTime = currentTime + datetime.timedelta(days=28)
    currentTime = currentTime.strftime("%Y-%m-%d %H:%M")
    dueTime = dueTime.strftime("%Y-%m-%d %H:%M")
    ins = ins.values(BookId=bookId, BranchId=input2, CardNo=input1, DateOut=currentTime, DueDate=dueTime,
                     returned=str(0))
    conn = engine.connect()
    result = conn.execute(ins)
def minusNoOfCopies(input2,bookId):
    book_copies = queryBook_Copiesby_branchidAndbookid(input2, bookId).first()
    no_of_copies = book_copies.No_Of_Copies
    queryBook_Copiesby_branchidAndbookid(input2, bookId).update({"No_Of_Copies": str(no_of_copies - 1)})
    session.commit()

@app.route('/releaseBook', methods=['POST', 'GET'])
def releaseBook():
    input = request.form['bookName']  # input book Name

    input1 = request.form['cardId']  # input cardno

    input2 = request.form['branchId']  # input branchId

    if not queryBookby_title(input):
        return jsonify({'message': ['error', 'there is no book title found']})
    if not queryBorrowerby_cardno(input1):
        return jsonify({'message': ['error', 'there is no card Number found']})
    if not queryBranchby_branchid(input2):
        return jsonify({'message': ['error', 'there is no Branch Id found']})
    book = queryBookby_title(input)
    bookId = book.bookid
    # add record to Book_Loans
    addLoansRecord(bookId, input2, input1)
    #minus book number of branch
    minusNoOfCopies(input2, bookId)
    return jsonify({'message': ['success', 'Release Book successfully']})

def addNoOfCopies(input2,bookId):
    book_copies = queryBook_Copiesby_branchidAndbookid(input2, bookId).first()
    no_of_copies = book_copies.No_Of_Copies
    queryBook_Copiesby_branchidAndbookid(input2, bookId).update({"No_Of_Copies": str(no_of_copies + 1)})
    session.commit()
def updateBook_Loans(cardno,branchId,bookId):
    session.query(Book_Loans).filter(Book_Loans.c.BookId == bookId,
                                     Book_Loans.c.BranchId == branchId,
                                     Book_Loans.c.CardNo == cardno).\
        update({"returned":str(1)})
    session.commit()

@app.route('/returnBook', methods=['POST', 'GET'])
def returnBook():
    input = request.form['bookName']  # input book Name

    input1 = request.form['cardId']  # input cardno

    input2 = request.form['branchId']  # input branchId
    # if input has some error
    if not queryBookby_title(input):
        return jsonify({'message': ['error', 'there is no book title found']})
    if not queryBorrowerby_cardno(input1):
        return jsonify({'message': ['error', 'there is no card Number found']})
    if not queryBranchby_branchid(input2):
        return jsonify({'message': ['error', 'there is no Branch Id found']})
    book = queryBookby_title(input)
    bookId = book.bookid
    #update record of Book_Loans
    updateBook_Loans(input1,input2,bookId)
    # add book number of branch
    addNoOfCopies(input2, bookId)
    return jsonify({'message': ['success', 'Return Book successfully']})

@app.route('/expiredBooksNew', methods=['POST', 'GET'])
def expiredBooksNew():

    return 'Hello'

@app.route('/', methods=['POST', 'GET'])
def loadIndex():
    return render_template('index.html')

@app.route('/loadSearchResult', methods=['POST', 'GET'])
def loadSearchResult():
    return render_template('searchResult.html')

@app.route('/admin', methods=['POST', 'GET'])
def admin():
    return render_template('staff_search.html')

@app.route('/viewBranch', methods=['POST', 'GET'])
def viewBranch():
    return render_template('View_the_branch.html')

@app.route('/borrowerRecord', methods=['POST', 'GET'])
def borrowerRecord():
    return render_template('Borrower_record.html')

@app.route('/releaseBookNew', methods=['POST', 'GET'])
def releaseBookNew():
    return render_template('Release_book.html')

@app.route('/returnBookNew', methods=['POST', 'GET'])
def returnBookNew():
    return render_template('Return_book.html')

@app.route('/expiredBooks', methods=['POST', 'GET'])
def expiredBooks():
    return render_template('Expired_books.html')
if __name__ == '__main__':
   app.run(debug=True)
