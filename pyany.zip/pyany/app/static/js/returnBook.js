clickButton = () =>{
    $('#releaseBookSubmit').bind('click',function(){
        clickFunction()
    })
    
}

clickFunction = () =>{
    branchId = $('#branchId').val()
    cardId = $('#cardId').val()
    bookName = $('#bookNameId').val()
    console.log('it work')
    // input = request.form['bookName']  # input book Name

    // input1 = request.form['cardId']  # input cardno

    // input2 = request.form['branchId']  # input branchId
    url = 'http://127.0.0.1:5000/returnBook'
    data = {'bookName':bookName,'cardId':cardId,'branchId':branchId}
    Ajax(url,data,'post',returnBookSf,ef)
}

returnBookSf = (result) =>{
    if(result.message[0] == 'success'){
        result = result.message[1]
        $('#releaseInfo').html(
           ("<div class='alert alert-success' role='alert'>"+
           " <p> "+result+""+
           "</div>")
        )
    }else{
        result = result.message[1]
        $('#releaseInfo').html(
            ("<div class='alert alert-warning' role='alert'>"+
            " <p> "+result+"</p>"+
            "</div>")
         )
    }
}
