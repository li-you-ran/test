searchBook = () =>{
    $('#searchBook').bind('click',function(){
        searchFunction()
    })
}
/*
* collect usr input
* clearify url,data,postMethod
* send ajax
*/

searchFunction = () =>{
    //console.log('get it')
    authorNameOrTitle = $('#searchContent').val()
    url = "http://127.0.0.1:5000/publichSearch"
    data = {'authorNameOrTitle':authorNameOrTitle}
    Ajax(url,data,'post',searchBookSf,ef)
}

searchBookSf = (result) => {
    console.log(result)
    if(result.message[0] == 'success'){
        result = result.message[1]
        var dic = {};
        var array = new Array()
        
        result.forEach((item,index) =>
            {
                
                array.push(item.branchName+":"+item.leftNumber)
                bookName = item.bookName
                authorName = item.authorName
                publisher = item.publisher
                console.log(publisher)
            }
        )
        array.forEach((item,index) =>{
            $('#branchNameId').append(
                ("<h6><span>"+item.split(':')[0]+"</span>:&nbsp"+
                        "<span>"+item.split(':')[1]+"</span>&nbsp books&nbsp"+
                        "</h6>"
                        )
            )
        })
        $('#bookNameId').html('Book Name:&nbsp'+bookName)
        $('#authorNameId').html('Author Name:&nbsp'+authorName)
        $('#publisherId').html('Publisher Name:&nbsp'+publisher)
    }else{
        errorMessage = result.message[1]
        $('#errorId').html('Error Message:&nbsp' +errorMessage)
    }
}