searchButton = () =>{
    $('#button-addon2').bind('click',function(){
        clickButton()
    })
}
/*
* collect user input as data use ajax to send
* ajax need to clarify url, data, post method
* ajax end point is loadBorrowerRecord
* loadRecord receive input cardNo
* define success function
*/
clickButton = () =>{
    var inputContent =  $('#inputContentId').val()
    
    url = 'http://127.0.0.1:5000/loadBorrowerRecord'

    data = {'cardNo':inputContent}
    
    Ajax(url,data,'post',loadRecordSf,ef)
}

/*
* get data from end point as result
* load result to front end
*/
loadRecordSf = (result) =>{
    if (result.message[0] == 'success'){
        result = result.message[1]
        // lstResult.append({'bookName':book.title,
        // 'branchName':i[1],
        // 'borrowerName':borrower.name,
        // 'dateOut':i[8],
        // 'dueDate':i[9],
        // 'returnState':i[10]})
        var returnState = ''
        var style = ''
        result.forEach((item,index) => {
            if (item.returnState == '1'){
                returnState = 'Returned'
                
                color = '#189157'
            }else{
                returnState = 'Not yet'
                color = '#ef1e08'
                //<span style="color: #ef1e08;"></span>
            }
            $('#showResultId').append(
                ("<div class='media text-muted pt-3'>"+
                "  <p class='media-body pb-3 mb-0 small lh-125 border-bottom border-gray'>"+
                "    <strong class='d-block text-gray-dark'>BookName: <span>"+item.bookName+"</span>&nbsp &nbsp<span style ='color:"+color+"'>"+returnState+"</span></strong><br/>"+
                "    <span>Borrower Name </span> "+item.borrowerName+"</br>"+
                "    <span>Date Out</span> "+item.dateOut+"</br>"+
                "    <span>Due Date</span> "+item.dueDate+""+
                "  </p>"+
                "</div>")
            )
        });
        
    }else{
        result = result.message[1]
        $('#showResultId').append("<p>"+result+"</p>")
    }
    $('#seachAreaId').html('')
}
