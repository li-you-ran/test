Ajax = (url,data,type,sF,eF) => {
    $.ajax({
        "url":url,
        "data":data,
        "type":type,
        "dataType":'json',
        success: function(result){
            sF(result)// we need to define how successful function looks like
        },
        error: function(result){
            eF(result)// define error function
        }
    })
}

ef = () => {
    console.log('some error happens')
}