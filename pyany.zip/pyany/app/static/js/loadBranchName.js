
loadBranchName = () =>{
    //console.log('it works')
    url = 'http://127.0.0.1:5000/loadLibraries'
    data = '';
    Ajax(url,data,'post',loadBranchSf,ef)
}


loadBranchSf = (result) => {
    result.forEach((item,index) => {
        id = 'b' + index 
        //console.log(item)
        content = 'b' + index + '_content'
        if (index == '0'){
            $('#v-pills-tab').append(
                ("<a class='nav-link active' id='"+id+"' onclick = clickLibrary('"+id+"') data-toggle='pill' href='#"+content+"' role='tab' aria-selected='true'>"+item.library_branchName+"</a>")
            )
            $('#v-pills-tabContent').append(
                ("<div class='tab-pane fade show active' id='"+content+"' role='tabpanel' aria-labelledby='v-pills-home-tab'>"+
                "</div>")
            )
            
        }else{
            $('#v-pills-tab').append(
                ("<a class='nav-link' id='"+id+"' onclick = clickLibrary('"+id+"') data-toggle='pill' href='#"+content+"' role='tab'  aria-selected='false'>"+item.library_branchName+"</a>")
            )

            $('#v-pills-tabContent').append(
                ("<div class='tab-pane fade' id='"+content+"' role='tabpanel' aria-labelledby='v-pills-profile-tab'></div>")
            )
        }
    });
}

clickLibrary = (id) =>{
    // lname = $('#'+id).val()
    branchName = $('#'+id).text()

    url = "http://127.0.0.1:5000/loadBookofLibrary"
    data = {'branchName':branchName}
    // Ajax(url,data,'post',loadBookOfLibrary,ef)

    $.ajax({
        "url":url,
        "data":data,
        "type":'post',
        "dataType":'json',
        success: function(result){
            
            content = id + '_content'
            $("#"+content).html('')
            result.forEach((item,index) => {
        
                $("#"+content).append(
                    ("<p>bookName: "+item.bookName+", &nbsp publish by: "+item.publisher+", &nbsp how many book left:  "+item.bookleft+"</p>")
                )
                
            })
        },
        error: function(result){
            eF(result)// define error function
        }
    })
}


loadBookOfLibrary = (result) =>{
    console.log(id)
    $("#b0_content").html('')

    result.forEach((item,index) => {
        
        $("#b0_content").append(
            ("<p>bookName: "+item.bookName+",publish by: "+item.publisher+", how many book left:  "+item.bookleft+"</p>")
        )
        
    })
    
}
searchBook = () =>{
    $('#searchBook').bind('click',function(){
        searchFunction()
    })
}

searchFunction = () =>{
    //console.log('get it')
    authorNameOrTitle = $('#searchContent').val()
    url = "http://127.0.0.1:5000/publichSearch"
    data = {'authorNameOrTitle':authorNameOrTitle}
    Ajax(url,data,'post',searchBookSf,ef)
}

searchBookSf = (result) => {
    console.log(result.message[0])
    if(result.message[0] == 'success'){
        
        result = result.message[1]
        var dic = {};
        var array = new Array()
        result.forEach((item,index) =>
            {
                
                array.push(item.branchName+":"+item.leftNumber)
                bookName = item.bookName
                authorName = item.authorName
                publisher = item.publisher
                console.log(publisher)
            }
        )
        //console.log(authorName)
        //console.log(array)
        dic['branchName'] = array
        dic['bookName'] = bookName
        dic['publisher'] = publisher
        dic['authorName'] = authorName
        //console.log(array)
        $(location).attr('href','http://127.0.0.1:5000/loadSearchResult?branchName='+dic['branchName']+'&bookName='+dic['bookName']+'&authorName='+dic['authorName']+'&publisher='+dic['publisher'])
    }else{
        result = result.message[1]
        
        $(location).attr('href','http://127.0.0.1:5000/loadSearchResult?errorMessage='+result)

    }

}


